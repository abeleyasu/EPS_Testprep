# Videodetector for CK Editor
This plugin allows you to insert videos from Youtube, Vimeo or Dailymotion only pasting an URL or embed code. The inserted videos will catch the full CKEditor width and will be fully responsive.

Developed by [Dimitri Conejo](https://www.dimitriconejo.com).

### MIT Licence
